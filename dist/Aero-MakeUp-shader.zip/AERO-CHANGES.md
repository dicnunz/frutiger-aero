Modified 2026-10-08 by GPT-6.1 Sol Max for Nicholas Dunzelman.

Adapted for Frutiger Aero by GPT-6.1 Sol Max. Upstream: Javier Garduño, MakeUp Ultra Fast 9.5g, LGPL-3.0. https://github.com/javiergcim/MakeUpUltraFast
Changes: cool daylight palette, transparent turquoise water, soft shadows, custom ceramic material tags. Original GLSL retained.

Version 2 playback defaults: adjacent physical flow plates in the mod, flipped reflections, vanilla clouds, 300-pixel shadows, three AO samples, and no volumetric light. These retain reflective water, clear glass, soft shadows and TAA while reducing GPU work.

Iris dimension.properties explicitly maps aero:retreat to the Overworld shader programs. The generic deferred pass now uses the fog constant defined for unknown dimensions when volumetric light is off. This fixes a custom-dimension compile failure.
